﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TheDataResourceImporter
{
    public partial class ImportHistory : Form
    {
        public ImportHistory()
        {
            InitializeComponent();
        }

        //页面加载
        private void ImportHistory_Load(object sender, EventArgs e)
        {

        }
    }
}
