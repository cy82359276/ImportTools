﻿// 为模型“D:\CSharp Workspace\TheDataResourceImporter VS14\TheDataResourceImporter\DataResourceEntities.edmx”启用了 T4 代码生成。
// 要启用旧代码生成功能，请将“代码生成策略”设计器属性的值
// 更改为“旧的 ObjectContext”。当在设计器中打开该模型时，此属性会出现在
// “属性”窗口中。

// 如果没有生成任何上下文和实体类，可能是因为您创建了空模型但是
// 尚未选择要使用的实体框架版本。要为您的模型生成一个上下文类和实体
// 类，请在设计器中打开该模型，右键单击设计器图面，然后
// 选择“从数据库更新模型...”、“从模型生成数据库...”或“添加代码生成
// 项...”。